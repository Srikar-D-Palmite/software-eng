var searchData=
[
  ['stack_5ftypes_2eh_0',['stack_types.h',['../stack__types_8h.html',1,'']]],
  ['stacks_2ecpp_1',['stacks.cpp',['../stacks_8cpp.html',1,'']]]
];
